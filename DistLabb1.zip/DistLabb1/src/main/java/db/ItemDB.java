package db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.Vector;

public class ItemDB extends bo.Item {

    private ItemDB(String name, int price) {
        super(name, price);
    }

    public static Collection getItems(){
        Vector v  = new Vector();
        try{
            Connection con = DBManager.getConnection();
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("select * from t_item");

            while(rs.next())
            {
                String name = rs.getString("name");
                int price = rs.getInt("price");

                v.addElement(new ItemDB(name,price));
            }
        } catch (SQLException throwables) { throwables.printStackTrace(); }
        return v;
    }
}
