package db;

import bo.User;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDB extends bo.User {

    private UserDB(String username, String password)
    {
        super(username, password);
    }

    public static boolean registerUser(User user)
    {
        boolean check = false;
        try {
            Connection con = DBManager.getConnection();
            Statement stmt = con.createStatement();
            String addquery = "INSERT INTO t_user (username,password) VALUES ('" + user.getUsername() + "'" + ","  + "'" + user.getPassword() + "'" +  ")" + "";
            stmt.execute(addquery);
            check = true;
        }
        catch (SQLException ex)
        {

            Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
            return check;
        }
        return check;
    }
    public static boolean checkUser(User user)
    {
        boolean check = false;
        try{
            Connection con = DBManager.getConnection();
            Statement statement = con.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM t_user WHERE username LIKE '%" + user.getUsername()+ "%'");

            if(rs.next())
            {
                String uname = rs.getString("username");
                String password = rs.getString("password");
                if(uname.equals(user.getUsername()) && password.equals(user.getPassword()))
                {
                    check = true;
                }
            }
        } catch (SQLException throwables) { throwables.printStackTrace(); }
        return check;
    }
}

