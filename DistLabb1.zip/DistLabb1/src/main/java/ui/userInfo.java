package ui;

public class userInfo {
    private static String userName;

    public userInfo(String userName)
    {
        this.userName = userName;
    }

    public static String getUserName() {
        return userName;
    }
}
