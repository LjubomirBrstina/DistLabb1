package servlets;

import bo.UserHandler;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class registerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/register.jsp").forward(request,response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String password = request.getParameter("Password");
        if(name=="" || password == "")
        {
            request.setAttribute("error","please enter both fields");
            doGet(request,response);
        }
        else if(UserHandler.registerUser(name,password))
        {
            response.sendRedirect("/login.jsp");
        }
        else
        {
            request.setAttribute("error","Username is already taken");
            doGet(request,response);
        }
    }
}
