package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
public class helloServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        response.getWriter().println("<h1>Welcome to our Webshop!</h1>");
    }

}
