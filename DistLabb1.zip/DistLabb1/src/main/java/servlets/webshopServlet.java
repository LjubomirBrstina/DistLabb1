package servlets;

import bo.ItemHandler;
import ui.ItemInfo;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class webshopServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if(action==null)
        {
            list(request, response);
        }
        switch (action) {
            case "add":
                addToChart(request, response);
                break;
            default:
                list(request, response);
                break;
        }
    }

    private void addToChart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        HttpSession session = request.getSession();

        String itemName = request.getParameter("name");
        int price = Integer.parseInt(request.getParameter("price"));

        if (session.getAttribute("cart") == null)
        {
            ArrayList<ItemInfo> cart = new ArrayList<>();
            cart.add(new ItemInfo(itemName,price));
            session.setAttribute("cart", cart);
        }
        else
        {
            ArrayList<ItemInfo> cart = (ArrayList<ItemInfo>) session.getAttribute("cart");
            cart.add(new ItemInfo(itemName,price));
            session.setAttribute("cart", cart);
        }

        request.getRequestDispatcher("cart.jsp").forward(request, response);
    }

    private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<ItemInfo> itemList = ItemHandler.getItems();
        request.setAttribute("itemList",itemList);

        getServletContext().getRequestDispatcher("/webshop.jsp").forward(request,response);
    }
}
