package servlets;


import bo.UserHandler;
import ui.userInfo;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class loginServlet extends HttpServlet {

    static userInfo activeUser = null;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(activeUser!=null)
        {
            response.setContentType("text/html");
            response.getWriter().println("<h1>" + activeUser.getUserName() +" är redan inloggad<h1>");
            response.getWriter().println("<form method=\"post\" action=\"/login\"> " +
                    "<tr>\n" +
                    "                <td><input type=\"submit\" name=\"logout\"value=\"Logout\"\n" +
                    "                /></td>\n" +
                    "            </tr>");

        }
        else {
            getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(request.getParameter("logout")!=null)
        {
            activeUser = null;
            getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
        }
        String name = request.getParameter("uname");
        String password = request.getParameter("pass");

        if(name=="" || password == "")
        {
            request.setAttribute("error","you are missing one of the inputs");
            doGet(request,response);
        }
        else {
            if(UserHandler.checkUser(name,password))
            {
                activeUser = new userInfo(name);
                response.sendRedirect("/index.jsp");
            }
            else {
                request.setAttribute("error","invalid username and/or password");
                doGet(request,response);
            }
        }
    }
}
