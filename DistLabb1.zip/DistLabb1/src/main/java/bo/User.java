package bo;

import db.UserDB;

/**
 * Business logic class to represent an user
 */

public class User
{
    private final String username;
    private final String password;

    protected User(String username, String password)
    {
        this.username = username;
        this.password = password;
    }
    public static boolean checkUser(User user)
    {
        return UserDB.checkUser(user);
    }
    public static boolean registerUser(User user)
    {
        return UserDB.registerUser(user);
    }
    public String getUsername()
    {
        return username;
    }
    public String getPassword()
    {
        return password;
    }
}