package bo;

public class UserHandler {
    public static boolean checkUser(String username, String password)
    {
        return User.checkUser(new User(username,password));
    }
    public static boolean registerUser(String username, String password)
    {
        return User.registerUser(new User(username,password));
    }
}
