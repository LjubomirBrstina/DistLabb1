package bo;

import db.ItemDB;

import java.util.Collection;

public class Item {

    private String name;
    private int price;

    public static Collection getItem(){
        return ItemDB.getItems();
    }
    protected Item(String name, int price)
    {
        this.name = name;
        this.price = price;
    }
    public String getName()
    {
        return this.name;
    }
    public int getPrice()
    {
        return this.price;
    }
}

