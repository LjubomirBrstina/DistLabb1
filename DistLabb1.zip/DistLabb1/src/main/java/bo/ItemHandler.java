package bo;

import ui.ItemInfo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class ItemHandler {
    public static List<ItemInfo> getItems()
    {
        Collection c = Item.getItem();
        ArrayList<ItemInfo> items = new ArrayList<ItemInfo>();
        for(Iterator it = c.iterator();it.hasNext();){
            Item item = (Item) it.next();
            items.add(new ItemInfo(item.getName(),item.getPrice()));
        }
        return items;
    }
}
