package DB;

import Bo.Item;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DBManager {

    private static final List<Item> items = new ArrayList<>();
    private static ResultSet rset;
    private static Connection con = null;
    
    private DBManager(){
        try{
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String user = "Client"; // user name        
        String pwd = "Client123"; // password         
        String database = "Labb1Dist"; // the name of the specific database         
        String server = "jdbc:mysql://localhost:3306/" + database + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useClientEnc=UTF8";
        con = DriverManager.getConnection(server, user, pwd);
        } 
        catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {}
    }
    
    //Reines grejer
    private static DBManager instance = null;
    
    public static Connection getConnection() throws SQLException {
        return getInstance().con;
    }
    
    private static DBManager getInstance() throws SQLException {
        if (instance == null) {
            instance = new DBManager();
        }
        return instance;
    }
    
    public static void main(String[] args) throws Exception {
        connect();
        List<Item> itemsFromDb = getItemsFromDb();
        for(int i=0;i<itemsFromDb.size();i++){
            System.out.println(itemsFromDb.get(i));
        }
        disconnect();
    }

    public static boolean connect() throws SQLException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
        Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        String user = "Client"; // user name        
        String pwd = "Client123"; // password         
        String database = "Labb1Dist"; // the name of the specific database         
        String server = "jdbc:mysql://localhost:3306/" + database + "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&useClientEnc=UTF8";
        con = DriverManager.getConnection(server, user, pwd);
        return true;
    }
    
    public static void disconnect() throws IOException, SQLException {
        items.clear();
        con.close();
    }

    public static List<Item> createResult(){
        List<Item> result = new ArrayList<>();
        items.forEach(b -> {
            result.add(b);
        });
        return result;
    }
    
    public static List<Item> getItemsFromDb() throws IOException, SQLException {
        try(Statement stmt = con.createStatement()){
            String sql = "SELECT * FROM Item";
            rset = stmt.executeQuery(sql);
            while (rset.next()) {
                int tmpId = rset.getInt("ItemId");
                String tmpN = rset.getString("Name");
                String tmpD = rset.getString("Description");
                Item item = new Item(tmpId, tmpN, tmpD);
                items.add(item);
            }
            List<Item> result = createResult();
            return result;
        } 
        finally {
            rset.close();
            items.clear();
        }
    }
}