/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DB;

import Bo.Item;
import java.util.List;

/**
 *
 * @author ljubo
 */
/*public class maintest {
    public static void main(String[] args) throws Exception {
        DBManager d = new DBManager();
        //connect();
        List<Item> itemsFromDb = d.getItemsFromDb();
        for(int i=0;i<itemsFromDb.size();i++){
            System.out.println(itemsFromDb.get(i));
        }
        d.disconnect();
    }
}*/
