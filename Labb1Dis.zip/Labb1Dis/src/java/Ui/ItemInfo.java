/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ui;

/**
 *
 * @author ljubo
 */
public class ItemInfo {
    private String name;
    private String descr;
    public ItemInfo(String name, String descr) {
        this.name = name;
        this.descr = descr;
    }
    public String getDescription(){
        return descr;
    }
    public void setDescription(String desc){
        this.descr = desc;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
}
