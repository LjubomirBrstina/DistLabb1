package Bo;
import DB.ItemDB;
import java.util.Collection;
/**
 *
 * @author ljubo
 */
public class Item {
    private String name;
    private String descr;
    private int id;
    
    static public Collection searchItems(String group){
        return ItemDB.searchItems(group);
    }
    
    public Item(int id, String name, String desc){
        this.id = id;
        this.name = name;
        this.descr = desc;
    }
    
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getDescr(){
        return this.descr;
    }
    public void setDescr(String Desc){
        this.descr = Desc;
    }
    public int getId(){
        return this.id;
    }
    @Override
    public String toString(){
        String s = "";
        s = this.name + " " + this.descr + " " + this.id;
        return s;
    }
}
