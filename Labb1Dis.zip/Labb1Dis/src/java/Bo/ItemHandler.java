package Bo;

import static DB.DBManager.connect;
import static DB.DBManager.disconnect;
import static DB.DBManager.getConnection;
import static DB.DBManager.getItemsFromDb;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import Ui.ItemInfo;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author ljubo
 */
public class ItemHandler {
    private static List<Item> dbItems = new ArrayList<Item>();
    private static List<Item> Cart = new ArrayList<Item>();
    public static Collection<ItemInfo> getItemsWithGroup(String s) {
        Collection c = Item.searchItems(s);
        ArrayList<ItemInfo> items = new ArrayList<ItemInfo>();
        for (Iterator it = c.iterator(); it.hasNext();) {
            Item item = (Item) it.next();
            items.add(new ItemInfo(item.getName(), item.getDescr()));
        }
        return items;
    }

    public static void addToCart(int id) {
        for(int i=0;i<dbItems.size();i++){
            if(dbItems.get(i).getId()==id){
                Cart.add(dbItems.get(i));
                break;
            }
        }
    }

    public static List getCart() {
        return Cart;
    }
    public static void clearCart(){
        Cart.clear();
    }
    
    public static List<Item> ItemList() throws IOException, SQLException, InstantiationException, ClassNotFoundException, IllegalAccessException{
        connect();
        dbItems = getItemsFromDb();
        disconnect();
        return dbItems;
    }
}
